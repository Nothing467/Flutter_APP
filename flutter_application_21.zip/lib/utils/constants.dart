import 'package:flutter/material.dart';

const String APP_NAME = "Multi-Service App";
const String API_BASE_URL = "https://api.example.com";

const kPrimaryColor = Color(0xFF6F35A5);
const kPrimaryLightColor = Color(0xFFF1E6FF);
