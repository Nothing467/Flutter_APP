import 'package:flutter/material.dart';

class FitnessTrainingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Fitness Training'),
      ),
      body: Center(
        child: Text('Fitness Training Screen'),
      ),
    );
  }
}
