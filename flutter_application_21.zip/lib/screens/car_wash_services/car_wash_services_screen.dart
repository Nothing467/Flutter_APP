import 'package:flutter/material.dart';

class CarWashServicesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Car Wash Services'),
      ),
      body: Center(
        child: Text('Car Wash Services Screen'),
      ),
    );
  }
}
