import 'package:flutter/material.dart';

class HomeServicesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Services'),
      ),
      body: Center(
        child: Text('Home Services Screen'),
      ),
    );
  }
}
