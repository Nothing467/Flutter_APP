import 'package:flutter/material.dart';

class EventPlanningScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Event Planning'),
      ),
      body: Center(
        child: Text('Event Planning Screen'),
      ),
    );
  }
}
