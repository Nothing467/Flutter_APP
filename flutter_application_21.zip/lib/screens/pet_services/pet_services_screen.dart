import 'package:flutter/material.dart';

class PetServicesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pet Services'),
      ),
      body: Center(
        child: Text('Pet Services Screen'),
      ),
    );
  }
}
