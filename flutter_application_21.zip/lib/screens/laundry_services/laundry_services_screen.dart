import 'package:flutter/material.dart';

class LaundryServicesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Laundry Services'),
      ),
      body: Center(
        child: Text('Laundry Services Screen'),
      ),
    );
  }
}
